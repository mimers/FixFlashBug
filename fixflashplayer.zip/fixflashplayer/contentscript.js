var retry_times = 0;
function clearWmodeParam() {
var pams = document.querySelectorAll("object param");
var gotone = false;
	for (var i = 0; i < pams.length; i++) {
		if(pams[i].name == "wmode")
		{
			pams[i].parentNode.removeChild(pams[i]);
			gotone=true;
		}
	};
	if (!gotone){
		if(retry_times++ < 10)
			setTimeout(clearWmodeParam,1000)
	}
}
clearWmodeParam();